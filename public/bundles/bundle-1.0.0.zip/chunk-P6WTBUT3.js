import{b as a,c as b}from"./chunk-PD2PSGYJ.js";import"./chunk-7CGTOI24.js";export{a as GESTURE_CONTROLLER,b as createGesture};
